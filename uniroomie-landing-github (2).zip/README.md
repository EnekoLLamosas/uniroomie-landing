# UniRoomie Landing Page
Landing para captar emails de estudiantes interesados en la app UniRoomie.